import streamlit as st
import pickle

st.set_page_config(
    page_title= "Malayalam movie recommendation",
    layout='wide',
    initial_sidebar_state='collapsed'
)

movie = pickle.load(open('movie_detail.pkl', 'rb'))
similarity = pickle.load(open('similarity.pkl', 'rb'))
poster_data = pickle.load(open('poster.pkl', 'rb'))

def display_currentmovie(film):
    id = movie[movie['Title']== film].index[0]
    detail = movie.loc[id]
    poster = detail['poster']
    poster = poster_data.loc[id].Poster_url
    cols = st.columns([1, 2, 3, 1], gap="large")
    with cols[1]:
        frame = st.container(border=True)
        frame.image(poster)
        #frame.image('https://m.media-amazon.com/images/M/MV5BZDZhZjA2YjYtYTM0ZS00YmE0LWI3NDItMzg0ZDhiN2ZhZjZhXkEyXkFqcGdeQXVyMjkxNzQ1NDI@._V1_.jpg' , width = 200)
        #frame.image('https://m.media-amazon.com/images/M/MV5BNjUyZGYwNGItYTVjYy00ZTgyLTkzMzItMmNmNWNhYWI4OTk1XkEyXkFqcGdeQXVyMTEzNzg0Mjkx._V1_.jpg')
    with cols[2]:
        detail = movie.loc[id]
        st.write("TITLE: " + detail["Title"])
        st.write("Director: " + detail['Directors'])
        st.write("OVERVIEW: ")
        st.write(detail['overview'])
        if detail['IMDb Rating'] != "":
            rating = detail['IMDb Rating']
        else:
            rating = "0"
        if detail['Num Votes'] != "":
            votes = detail['Num Votes']
        else:
            votes = "0"
        st.write("RATING: " + str(rating) + "/10" + "(" + str(votes) + " votes )")
        st.write("GENRE: " + detail['Genres'])
        r_date = detail['Release Date']
        st.write("RELEASE DATE: " + (r_date))



def recommend(film):
    index = movie[movie['Title']== film].index[0]
    distance = sorted(list(enumerate(similarity[index])),reverse = True, key = lambda vector:vector[1])
    movie_names = []
    movie_poster = []
    for i in distance[1:11]:
        movie_poster.append(poster_data.loc[i[0]].Poster_url)
        movie_names.append(movie.loc[i[0]].Title)
        
    return movie_names, movie_poster


def display_recommendations(movie):
    movie_names, movie_poster = recommend(movie)
    cols = st.columns(5)
    for i in range(5):
        with cols[i]:
            st.image(movie_poster[i], width=200)
            # st.image('https://m.media-amazon.com/images/M/MV5BNjUyZGYwNGItYTVjYy00ZTgyLTkzMzItMmNmNWNhYWI4OTk1XkEyXkFqcGdeQXVyMTEzNzg0Mjkx._V1_QL75_UY562_CR20,0,380,562_.jpg')
            # st.image('https://m.media-amazon.com/images/M/MV5BZDZhZjA2YjYtYTM0ZS00YmE0LWI3NDItMzg0ZDhiN2ZhZjZhXkEyXkFqcGdeQXVyMjkxNzQ1NDI@._V1_.jpg')
            st.write(movie_names[i])
    for i in range(5, 10):
        with cols[i % 5]:
            st.image(movie_poster[i], width=200)
            st.write(movie_names[i])



st.header("Movie Recommendation")
selected_movie = st.selectbox("Select a movie:", options=movie['Title'])
if st.button("Recommend"):
    cols = st.columns([1, 2, 1])
    with cols[1]:
        st.header('You selected movie ' + selected_movie, divider= True)
    display_currentmovie(selected_movie)
    cols = st.columns([2,1,2])
    with cols[1]:
        st.header('Recommendations', divider= True)
    display_recommendations(selected_movie)



    # https://m.media-amazon.com/images/M/MV5BNjUyZGYwNGItYTVjYy00ZTgyLTkzMzItMmNmNWNhYWI4OTk1XkEyXkFqcGdeQXVyMTEzNzg0Mjkx._V1_QL75_UY281_CR10,0,190,281_.jpg 190w, 
    # https://m.media-amazon.com/images/M/MV5BNjUyZGYwNGItYTVjYy00ZTgyLTkzMzItMmNmNWNhYWI4OTk1XkEyXkFqcGdeQXVyMTEzNzg0Mjkx._V1_QL75_UY422_CR15,0,285,422_.jpg 285w, 
    # https://m.media-amazon.com/images/M/MV5BNjUyZGYwNGItYTVjYy00ZTgyLTkzMzItMmNmNWNhYWI4OTk1XkEyXkFqcGdeQXVyMTEzNzg0Mjkx._V1_QL75_UY562_CR20,0,380,562_.jpg 380w


    # https://m.media-amazon.com/images/M/MV5BY2M0ZTk3ZTEtOTlkZi00NWU2LTkzM2QtNjBlMzgzZDU4MDJlXkEyXkFqcGdeQXVyNTI0NzYwMTI@._V1_QL75_UY281_CR8,0,190,281_.jpg 190w, 
    # https://m.media-amazon.com/images/M/MV5BY2M0ZTk3ZTEtOTlkZi00NWU2LTkzM2QtNjBlMzgzZDU4MDJlXkEyXkFqcGdeQXVyNTI0NzYwMTI@._V1_QL75_UY422_CR12,0,285,422_.jpg 285w, 
    # https://m.media-amazon.com/images/M/MV5BY2M0ZTk3ZTEtOTlkZi00NWU2LTkzM2QtNjBlMzgzZDU4MDJlXkEyXkFqcGdeQXVyNTI0NzYwMTI@._V1_QL75_UY562_CR16,0,380,562_.jpg 380w