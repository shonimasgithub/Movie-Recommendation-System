from bs4 import BeautifulSoup
import requests
import json
# url = 'https://www.imdb.com/title/tt0249188/'
# response = requests.get(url)
# soup = BeautifulSoup(response.content, 'html.parser')
# print(soup)
# movie_data = soup.findAll('div', attrs = {'id' : '__next'})
# print(movie_data)

import json

with open("Malayalam_data/new_json.json", "r") as f:
   # Read the contents of the file
   json_data = f.read()

# Parse the JSON data
data = json.loads(json_data)
print(data.keys())

#print(data['data'])
titles = []
for i in data['data']:
   titles.append(i['Title'])
print(titles)
# Access and print values based on your JSON structure
# (Example using a dictionary for demonstration)
# name = data["Title"]


# print("Name:", name)

"""
<div id="movieDetails" class="details-container">
        <img src="https://m.media-amazon.com/images/M/MV5BMzU0MjM3YTQtZmNjYi00ODI5LThhYzQtOWMwZjAxMjg2MTRjXkEyXkFqcGdeQXVyMjkxNzQ1NDI@._V1_QL75_UY562_CR3,0,380,562_.jpg"
            alt="0">
        <img src="https://m.media-amazon.com/images/M/MV5BYjJmZDc0N2MtMTU4NC00ZDNkLWJlYzItOTMwZWNlZDg5NDU3XkEyXkFqcGdeQXVyMjkxNzQ1NDI@._V1_.jpg"
            alt="0">
        <img src="https://m.media-amazon.com/images/M/MV5BY2Q2YWM3YjgtNzcyNy00MjczLWJiZGUtOWY5MDFhYmRiMDU3XkEyXkFqcGdeQXVyMjkxNzQ1NDI@._V1_.jpg"
            alt="0">
        <img src="https://m.media-amazon.com/images/M/MV5BZGRkODQ1NjItOWI3MS00OGZmLTk3MGYtMzFjOWM5NjVlOGQ3XkEyXkFqcGdeQXVyNjAyMzMzNjA@._V1_.jpg"
            alt="0">
        <img src="https://m.media-amazon.com/images/M/MV5BOTdhMWQ5YTYtNTNkMy00NGIzLWE2NjItYjhkYjQwMjljMDU1XkEyXkFqcGdeQXVyMjkxNzQ1NDI@._V1_.jpg"
            alt="0">

    
        <img src="https://m.media-amazon.com/images/M/MV5BM2RiZDVjYWEtZGNhYy00ZGU0LTgwZjMtZTJmNmMyNGQ5NGYyXkEyXkFqcGdeQXVyNjY1MTg4Mzc@._V1_.jpg"
            alt="0">
        <img src="https://m.media-amazon.com/images/M/MV5BYTZmYmI3OWEtNTIwOC00ODcwLWIwMGMtMWYwZWI3YzQ3NDJjXkEyXkFqcGdeQXVyMjkxNzQ1NDI@._V1_QL75_UX380_CR0,4,380,562_.jpg"
            alt="0">
        <img src="https://m.media-amazon.com/images/M/MV5BNjYxMWUwNGUtZmRmMy00MDZlLTgwNDMtODVlOGFjMTBlNGJkXkEyXkFqcGdeQXVyMjkxNzQ1NDI@._V1_QL75_UY562_CR3,0,380,562_.jpg"
            alt="0">
        <img src="https://m.media-amazon.com/images/M/MV5BZTgxY2MxZGItY2Q4Ny00NTRlLTg2MWEtYTY3Y2ZiMzAxMGU4XkEyXkFqcGdeQXVyNTA2MzMwMjA@._V1_.jpg"
            alt="0">
        <img src="https://m.media-amazon.com/images/M/MV5BMWRjMTUwY2MtOWMzYi00ZmZmLThhNzItOGIxM2I3M2U2MTIzXkEyXkFqcGdeQXVyMjkxNzQ1NDI@._V1_.jpg"
            alt="0">

    </div>
"""


"""
api link for getting perosn by name : "https://api.themoviedb.org/3/search/person?api_key=5f734f1803d88471b1eeb4587c834162&query=Mohanlal"

api link for getting person details by id : "https://api.themoviedb.org/3/person/82732?api_key=5f734f1803d88471b1eeb4587c834162"

complete link to get poster : "https://image.tmdb.org/t/p/w500/4oQtVIfXVpQESBgkjI9j9v7jMkQ.jpg"

omdb api link : "https://www.omdbapi.com/?i=tt15134398&apikey=45933def"

"""