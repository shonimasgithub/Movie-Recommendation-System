const questions = [
  {
    question: 'What is your favorite color?',
    options: ['Red', 'Blue', 'Green', 'Yellow'],
    answer: []
  },
  {
    question: 'What is your favorite animal?',
    options: ['Dog', 'Cat', 'Lion', 'Tiger'],
    answer: []
  },
  {
    question: 'What is your favorite food?',
    options: ['Pizza', 'Burger', 'Pasta', 'Sushi'],
    answer: []
  }
];

let currentQuestion = 0;
let selectedOptions = '';

function displayQuestion() {
  const questionElem = document.getElementById('question');
  const choicesElem = document.getElementById('choices');
  const options = questions[currentQuestion].options;

  questionElem.textContent = questions[currentQuestion].question;
  choicesElem.innerHTML = '';

  options.forEach((option, index) => {
    const inputElem = document.createElement('input');
    inputElem.type = 'checkbox';
    inputElem.id = "btn-check-outlined";
    inputElem.value = option;
    inputElem.name = 'options';
    inputElem.class = "btn-check";
    inputElem.autocomplete = "off";

    const labelElem = document.createElement('label');
    labelElem.class = "btn btn-outline-primary";
    labelElem.for = "btn-check-outlined";
    labelElem.textContent = option;

    const spanElem = document.createElement('span');

    labelElem.appendChild(inputElem);
    labelElem.appendChild(spanElem);

    choicesElem.appendChild(labelElem);
  });
}

function checkAnswer() {
  const inputElems = document.getElementsByName('options');
  questions[currentQuestion].answer = [];

  for (let i = 0; i < inputElems.length; i++) {
    if (inputElems[i].checked) {
      questions[currentQuestion].answer.push(inputElems[i].value);
    }
  }

  selectedOptions += questions[currentQuestion].answer.join(', ') + '\n';

  currentQuestion++;

  if (currentQuestion < questions.length) {
    displayQuestion();
  } else {
    document.getElementById('results').style.display = 'block';
    document.getElementById('results').textContent = selectedOptions;
  }
}

displayQuestion();

document.getElementById('next-btn').addEventListener('click', checkAnswer);